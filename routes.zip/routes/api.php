<?php

use App\Http\Controllers\Auth\LogoutController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\PostsController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\LikeController;
use App\Http\Controllers\OpportunityController;
use App\Http\Controllers\DonateController;
use App\Http\Controllers\ArchiveController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\EmailController;
use App\Http\Controllers\Auth\ForgotPasswordController;
use App\Http\Controllers\Auth\ResetPasswordController;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\GroupChatController;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum', 'verified')->get('/user', function (Request $request) {
    return $request->user();
});



//public routes
Route::post('/login', [LoginController::class, 'login']);
Route::post('/register', [RegisterController::class, 'register']);










Route::get('/notifs', [NotificationController::class, 'index']);
Route::post('/comments/{$com_id}/notifs', [NotificationController::class, 'storePostNotification']);
//Route::post('/members/{mem_id}/posts/{post_id}/Comments/{$com_id}/notifications',[NotificationController::class, 'storePostNotification']);
// Route::post('/sendemail', [EmailController::class, 'sendEmail']);

// Route::post('email/verification-notification', [EmailVerificationController::class, 'sendVerificationEmail'])->middleware('auth:sanctum');
// Route::get('verify-email/{id}/{hash}', [EmailVerificationController::class, 'verify'])->name('verification.verify')->middleware('auth:sanctum');
// Email verification routes
Route::get('/email/verify', 'App\Http\Controllers\Auth\VerificationController@show')
    ->name('verification.notice')
    ->middleware('auth:sanctum');

// Route::get('/email/verify/{id}/{hash}', 'App\Http\Controllers\Auth\VerificationController@verify')
//     ->name('verification.verify')
//     ->middleware('auth:sanctum');
Route::get('/email/verify/{id}/{hash}', function (EmailVerificationRequest $request) {
  $request->fulfill();
})->middleware(['auth:sanctum'])->name('verification.verify');

Route::post('/email/resend', 'App\Http\Controllers\Auth\VerificationController@resend')
    ->name('verification.resend')
    ->middleware('auth:sanctum');

Route::get('/forgot-password', [ForgotPasswordController::class, 'forgotPassword']
      // return view('auth.forgot-password');
  )->middleware('auth:sanctum')->name('password.request');

Route::get('/reset-password/{token}', [ResetPasswordController::class, 'resetPassword']
    // return view('auth.reset-password', ['token' => $token]);
)->middleware('auth:sanctum')->name('password.reset');

//protected routes
Route::group(['middleware' => ['auth:sanctum']], function () {
  Route::post('/logout', [LogoutController::class, 'logout']);

  Route::resource('/users', UserController::class);  
  Route::post('/users', [UserController::class, 'update']);
  Route::delete('/users', [UserController::class, 'destroy']);
  Route::get('search/{name}', [UserController::class, 'search']);
  Route::get('user', [UserController::class, 'show']);


  Route::resource('/posts', PostsController::class);

  Route::resource('/opps', OpportunityController::class);

  Route::resource('/donate', DonateController::class);

  Route::resource('/archive', ArchiveController::class);

  Route::resource('/posts/{post_id}/likes', LikeController::class);


  Route::resource('/posts/{post}/comments', CommentController::class);

  Route::post('/messages', [ChatController::class, 'sendPrivateMessage']);
  Route::get('/messages/{rd}', [ChatController::class, 'getPrivateMessage']);
  Route::get('/messages', [ChatController::class, 'fetchMessages']);
  Route::put('/messages/{id}', [ChatController::class, 'putPrivateMessage']);
  Route::delete('/messages/{id}', [ChatController::class, 'delPrivateMessage']);

  Route::resource('/group', GroupChatController::class);
  Route::post('/group/{id}/user', [GroupChatController::class, 'addUser']);


});

//Route::post('messages', [ChatController::class, 'sendPrivateMessage'])->middleware('auth:sanctum');

Route::post('/groupy', [ChatController::class, 'sendGroupMessage'])->middleware('auth:sanctum');
// Route::resource('/groupy', ChatController::class)->middleware('auth:sanctum');
Route::post('/sendemail', [EmailController::class, 'sendEmail']);